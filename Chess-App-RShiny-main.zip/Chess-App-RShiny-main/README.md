# Chess-App-RShiny

Krzysztof Sawicki, [Jakub Grzywaczewski](https://github.com/ZetrextJG), [Kacper Wnęk](https://github.com/KacWNK)

# About the project

The goal of the project was to create an app using Rshiny that presents data that we produced. We decided to use our chess game records from chess.com 

[App](https://grzywa.shinyapps.io/ChessExploRer/?fbclid=IwAR1R2O5ftHZtf-VkipzztX607Ni-_u4-hUfDVWkABFYoavvgSoF6vmUaXRA)

![ss1](https://user-images.githubusercontent.com/100801230/222732926-ec8c6e00-6d02-4c61-a9c3-df0d82552456.png)

![ss2](https://user-images.githubusercontent.com/100801230/222732966-31d02280-ea0c-40a3-921e-e4a8976f5ba6.png)

